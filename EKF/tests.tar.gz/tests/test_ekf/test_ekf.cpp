/****************************************************************************
 *
 *   Copyright (C) 2012 PX4 Development Team. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name PX4 nor the names of its contributors may be
 *    used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 ****************************************************************************/

/**
 * @file base.cpp
 *
 * Tests for the estimator base class
 */

#include <EKF/ekf.h>

#include <vector>
#include <array>

#include <fstream>
#include <stdio.h>

#include <cstdio>
#include <random>
#include <iostream>

std::vector<std::array<float,10>> imuData;
std::vector<gps_message> gpsData;
std::int64_t prev_stamp = 0;

// Read in the IMU data from file
//File saved in format:
//time_us accelX accelY accelZ GyroX GyroY GyroZ MagX MagY MagZ [vector(1,5)containing Baro measurements]
void read_imu(){

  std::ifstream inFile;    
  inFile.open("imu.dat", std::ios::in);    
  float  trash[5]; //tempf[10],
  std::array<float,10> tempf;

  while( !inFile.eof() ){
    inFile >> tempf[0] >> tempf[1] >> tempf[2] >> tempf[3] >> tempf[4] >> tempf[5] >> tempf[6] >> tempf[7] >> tempf[8] >> tempf[9] >> trash[0]>> trash[1]>> trash[2]>> trash[3]>> trash[4];
    imuData.push_back(tempf);
  }  
  inFile.close();
}


void read_gps(){
  
  std::ifstream inFile;    
  inFile.open("gps.dat", std::ios::in);  
  gps_message gps;
  float trash; //it is the centre of gravity
  while( !inFile.eof() ){    
    inFile >> gps.time_usec >> gps.lat >> gps.lon >> gps.alt >> gps.eph >> gps.epv >> gps.vel_m_s >> gps.vel_ned[0] >> gps.vel_ned[1] >> gps.vel_ned[2] >> trash >> gps.fix_type >> gps.nsats;	
	gps.yaw = NAN;
	gps.yaw_offset = 0.0f;
	gps.vel_ned_valid = true;
	gps.gdop = 5; //not sure
	gpsData.push_back(gps);
  }  
  inFile.close();
}

imuSample float2sample(std::array<float,10> imuD){
  imuSample output;
  output.time_us = imuD[0];
  output.delta_vel(0) = imuD[1];
  output.delta_vel(1) = imuD[2];
  output.delta_vel(2) = imuD[3];
  output.delta_ang(0) = imuD[4];
  output.delta_ang(1) = imuD[5];
  output.delta_ang(2) = imuD[6];
  output.delta_ang_dt = imuD[0] - prev_stamp;
  output.delta_vel_dt = imuD[0] - prev_stamp;
  prev_stamp = imuD[0];
  return output;
}

void clear_output(){
	std::ofstream outFile;            
	outFile.open("output.dat", std::ios::trunc);    
    outFile.close();
}

void write_imu(float* pos, float* vel, Quatf quat, uint64_t stamp){
  std::ofstream outFile;            
  outFile.open("output.dat", std::ios::app);  
  outFile << 1.0*stamp*1e-6 << " :\t\t[" << pos[0] << ", " << pos[1] << ", " << pos[2] << "]\t\t[" <<  quat(0) << ", " << quat(1) << ", " << quat(2) << ", " << quat(3) << "]\t\t[" << vel[0] << ", " << vel[1] << ", " << vel[2] << "]" << std::endl;  
  outFile.close();
}



int main(int argc, char *argv[])
{
	(void)argc; // unused
	(void)argv; // unused

	Ekf *ekf = new Ekf();
	std::cout << "EKF created" << std::endl;

	read_imu();
	std::cout << "IMU data read" << std::endl;

	read_gps();
	std::cout << "GPS data read" << std::endl;

	clear_output();

	for (auto& it : imuData)
    {   
      float pos[3], vel[3];
      Quatf quat;
      float temp[3]= {it[7], it[8], it[9]};
      uint64_t time = it[0];
      ekf->init(time);
      ekf->setIMUData(float2sample(it));      
      ekf->setMagData(it[0], temp );

	  for (auto& ti : gpsData){		  
		  if(ti.time_usec == it[0]){			  
      		ekf->setGpsData(ti.time_usec, ti);
		  }
	  }	
      // ekf2.setExtVisionData(uint64_t time_usec, ext_vision_message *evdata);

      ekf->update();
      quat = ekf->calculate_quaternion();
      ekf->get_position(pos);
      ekf->get_velocity(vel);
	  write_imu(pos, vel, quat, time);
    //   std::cout << time*1e-6 << ":\t[" << pos[0] << ", " << pos[1] << ", " << pos[2] << "] ; [" <<  quat(0) << ", " << quat(1) << ", " << quat(2) << ", " << quat(3) << "] ; [" << vel[0] << ", " << vel[1] << ", " << vel[2] << "]" << std::endl;
	}


	delete ekf;

	return 0;
}

/****************************************************************************
 *
 *   Copyright (C) 2012 PX4 Development Team. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name PX4 nor the names of its contributors may be
 *    used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 ****************************************************************************/

/**
 * @file base.cpp
 *
 * Tests for the estimator base class
 */

#include <EKF/ekf.h>

#include <vector>
#include <array>
#include <string>
#include <sstream>
#include <fstream>
#include <stdio.h>

#include <cstdio>
#include <random>
#include <iostream>
#include <mathlib/mathlib.h>

std::vector<std::array<float,11>> imuData;
std::vector<gps_message> gpsData;
std::vector<ext_vision_message> visData;
std::int64_t prev_stamp = 0;
imuSample prev_IMU;

// Read in the IMU data from file
//File saved in format:
//time_us accelX accelY accelZ GyroX GyroY GyroZ MagX MagY MagZ [vector(1,5)containing Baro measurements]
void read_imu(){

  std::ifstream inFile;    
  inFile.open("imu.dat", std::ios::in);    
  float  trash[4]; //tempf[10],
  std::array<float,11> tempf;

  while( !inFile.eof() ){
    inFile >> tempf[0] >> tempf[1] >> tempf[2] >> tempf[3] >> tempf[4] >> tempf[5] >> tempf[6] >> tempf[7] >> tempf[8] >> tempf[9] >> trash[0]>> trash[1]>> tempf[10]>> trash[2]>> trash[3];
	// std::cout << " " << tempf[0] << " " << tempf[1] << " " << tempf[2] << " " << tempf[3] << " " << tempf[4] << " " << tempf[5] << " " << tempf[6] << " " << tempf[7] << " " << tempf[8] << " " << tempf[9] << " " << trash[0]<< " " << trash[1]<< " " << tempf[10]<< " " << trash[2]<< " " << trash[3] << std::endl;	
    imuData.push_back(tempf);
  }  
  inFile.close();
}


void read_gps(){

std::ifstream inFile;    
  inFile.open("gps.dat", std::ios::in);  
  gps_message gps;
std::string line;
  int value;
  int nsats;
  while( std::getline(inFile, line) ) {    
	std::istringstream iss(line);	
    iss >> gps.time_usec >> gps.lat >> gps.lon >> gps.alt >> gps.eph >> gps.epv >> gps.vel_m_s >> gps.vel_ned[0] >> gps.vel_ned[1] >> gps.vel_ned[2] >> value >> gps.fix_type >> nsats;	
	
	gps.lat = gps.lat;
	gps.lon = gps.lon;
	gps.nsats = nsats;
	gps.alt = gps.alt;
	gps.vel_m_s = gps.vel_m_s;
	gps.vel_ned[0] = gps.vel_ned[0];
	gps.vel_ned[1] = gps.vel_ned[1];
	gps.vel_ned[2] = gps.vel_ned[2];
	gps.eph = 1.0f;
	gps.epv = 1.0f;
	gps.yaw = math::radians(value/100.0f -180.0f);	
	gps.yaw_offset = 0.0f;
	gps.vel_ned_valid = false;
	gps.sacc = 5.0f;
	gps.gdop = 0.0f; //not sure
	gpsData.push_back(gps);
  }  
  inFile.close();
}

void read_vis(){
  
  std::ifstream inFile;    
  inFile.open("vision.dat", std::ios::in);  
  ext_vision_message vis;  
  float temp;
  while( !inFile.eof() ){    
    inFile >> temp >> vis.posNED(0) >> vis.posNED(1) >> vis.posNED(2) >> vis.quat(0) >> vis.quat(1) >> vis.quat(2) >> vis.quat(3);	
	// std::cout << " " << temp << " " << vis.posNED(0) << " " << vis.posNED(1) << " " << vis.posNED(2) << " " << vis.quat(0) << " " << vis.quat(1) << " " << vis.quat(2) << " " << vis.quat(3) << std::endl;	

// TO test the EKF
	// vis.posNED(0) = 1.0f;
	// vis.posNED(1) = 0.0f;
	// vis.posNED(2) = 0.0f;
	// vis.quat(0) = 0.50f;
	// vis.quat(1) = 0.50f;
	// vis.quat(2) = 0.50f;
	// vis.quat(3) = 0.50f;
	vis.posErr = temp;
	vis.hgtErr = 0.1f;
	vis.angErr = 0.1f;	
	visData.push_back(vis);
  }  
  inFile.close();
}

imuSample float2sample(std::array<float,11> imuD){
  imuSample output;
  output.time_us = imuD[0];
  output.delta_ang_dt = (imuD[0] - prev_IMU.time_us)/1000000.0f; // from us to sec
  output.delta_vel_dt = (imuD[0] - prev_IMU.time_us)/1000000.0f; // from us to sec
  
  // according to the EKF2 main wrapper the delta_vel and delta_ang is the accelerometer*dt and gyro*dt   repsectively
  output.delta_vel(0) = (imuD[1]*output.delta_vel_dt);
  output.delta_vel(1) = (imuD[2]*output.delta_vel_dt);
  output.delta_vel(2) = (imuD[3]*output.delta_vel_dt);
  output.delta_ang(0) = imuD[4]*output.delta_ang_dt;
  output.delta_ang(1) = imuD[5]*output.delta_vel_dt;
  output.delta_ang(2) = imuD[6]*output.delta_vel_dt;
  
  prev_IMU.time_us = imuD[0];
  prev_IMU.delta_vel(0) = imuD[1];
  prev_IMU.delta_vel(1) = imuD[2];
  prev_IMU.delta_vel(2) = imuD[3];  
  prev_IMU.delta_ang(0) = imuD[4];
  prev_IMU.delta_ang(1) = imuD[5];
  prev_IMU.delta_ang(2) = imuD[6];
  
  return output;
}

void clear_output(bool gps_en){
	std::ofstream outFile;   
	if(gps_en){         
		outFile.open("out_gps.dat", std::ios::trunc);    
	}else{
		outFile.open("out_vis.dat", std::ios::trunc);    
	}
    outFile.close();
}

void write_imu(float* pos, float* vel, Quatf quat, uint64_t stamp, bool gps_en, uint32_t status, uint16_t fault){
  std::ofstream outFile;            
  if(gps_en){
	outFile.open("out_gps.dat", std::ios::app);  
  }else{
	outFile.open("out_vis.dat", std::ios::app);  
  }
  outFile << 1.0*stamp*1e-6 << "\t\t[ " << pos[0] << ", " << pos[1] << ", " << pos[2] << " ]\t\t[ " <<  quat(0) << ", " << quat(1) << ", " << quat(2) << ", " << quat(3) << " ]\t\t[ " << vel[0] << ", " << vel[1] << ", " << vel[2] << " ] [ " << status << " ] [ " << fault << " ]" << std::endl;  
  outFile.close();
}



int main(int argc, char *argv[])
{
	bool gps_enabled = true;
	(void)argc; // unused
	(void)argv; // unused
	
	Ekf *ekf = new Ekf();	
	std::cout << "EKF created" << std::endl;
	read_imu();
	std::cout << "IMU data read" << std::endl;
	if(gps_enabled){
		read_gps();
		std::cout << "GPS data read" << std::endl;
	}else{
		read_vis();
		std::cout << "Vision data read" << std::endl;
	}

	ekf->init(0);		
	clear_output(gps_enabled);	
	for (auto& it : imuData)
    {   
      float pos[3], vel[3];
      Quatf quat;
      float temp[3]= {it[7], it[8], it[9]};
      uint64_t time = it[0];	  

      ekf->setIMUData(float2sample(it)); 	
      ekf->setMagData(it[0], temp );	 	
	  ekf->setBaroData(it[0], it[10]/1000.0f);
	

	  if(gps_enabled){
		for (auto& ti : gpsData){		  
			if(abs(ti.time_usec - time) < 2000){					
				ekf->setGpsData(time, ti);				
				ekf->update();
			}
		}	
	  }else{		  
		for (auto&ti : visData) {
			if(abs(ti.posErr*1e6 - time)<2000){								
				ti.posErr = 0.1f;
				ekf->setExtVisionData(time, &ti);	  			
			}
	  	}
	  }
		ekf->update();	
		quat = ekf->calculate_quaternion();
		ekf->get_position(pos);
		ekf->get_velocity(vel);
		uint32_t status;
		uint16_t fault;
		ekf->get_control_mode(&status);
		ekf->get_filter_fault_status(&fault);
		write_imu(pos, vel, quat, time, gps_enabled, status, fault);	
		
	}
	delete ekf;

	return 0;
}
